'use client';

import maplibregl, { LngLatBoundsLike, Map } from 'maplibre-gl';
import type { FeatureCollection, Geometry } from 'geojson';
import { useEffect, useRef } from 'react';

type Props = {
  addressPoint: [number, number];
  closestPoint: [number, number];
  hexagon: Geometry;
};

function boundsFromCoordinates(coords: number[][]): [[number, number], [number, number]] {
  let minLon = Infinity, minLat = Infinity, maxLon = -Infinity, maxLat = -Infinity;
  for (const [lon, lat] of coords) {
    minLon = Math.min(minLon, lon); minLat = Math.min(minLat, lat);
    maxLon = Math.max(maxLon, lon); maxLat = Math.max(maxLat, lat);
  }
  return [[minLon, minLat], [maxLon, maxLat]];
}

function flattenGeometry(g: Geometry): number[][] {
  if (g.type === 'Polygon') return g.coordinates.flat(1) as number[][];
  if (g.type === 'MultiPolygon') return g.coordinates.flat(2) as number[][];
  return [];
}

export default function ResultMap({ addressPoint, closestPoint, hexagon }: Props) {
  const container = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<Map | null>(null);

  useEffect(() => {
    if (!container.current) return;

    const map = new maplibregl.Map({
      container: container.current,
      style: {
        version: 8,
        sources: {
          osm: {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '© OpenStreetMap contributors'
          }
        },
        layers: [{ id: 'osm', type: 'raster', source: 'osm' }]
      },
      center: addressPoint,
      zoom: 11
    });
    mapRef.current = map;
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');

    map.on('load', () => {
      const fc: FeatureCollection = {
        type: 'FeatureCollection',
        features: [
          { type: 'Feature', properties: { kind: 'hexagon' }, geometry: hexagon },
          { type: 'Feature', properties: { kind: 'line' }, geometry: { type: 'LineString', coordinates: [addressPoint, closestPoint] } },
          { type: 'Feature', properties: { kind: 'address' }, geometry: { type: 'Point', coordinates: addressPoint } },
          { type: 'Feature', properties: { kind: 'closest' }, geometry: { type: 'Point', coordinates: closestPoint } }
        ]
      };
      map.addSource('result', { type: 'geojson', data: fc });
      map.addLayer({
        id: 'hex-fill', type: 'fill', source: 'result',
        filter: ['==', ['get', 'kind'], 'hexagon'],
        paint: { 'fill-color': '#2d7d46', 'fill-opacity': 0.24 }
      });
      map.addLayer({
        id: 'hex-line', type: 'line', source: 'result',
        filter: ['==', ['get', 'kind'], 'hexagon'],
        paint: { 'line-color': '#176233', 'line-width': 3 }
      });
      map.addLayer({
        id: 'distance-line', type: 'line', source: 'result',
        filter: ['==', ['get', 'kind'], 'line'],
        paint: { 'line-color': '#18324a', 'line-width': 3, 'line-dasharray': [2, 2] }
      });
      map.addLayer({
        id: 'points', type: 'circle', source: 'result',
        filter: ['in', ['get', 'kind'], ['literal', ['address', 'closest']]],
        paint: { 'circle-radius': 6, 'circle-color': '#ffffff', 'circle-stroke-color': '#18324a', 'circle-stroke-width': 3 }
      });

      const coords = [...flattenGeometry(hexagon), addressPoint, closestPoint];
      const b = boundsFromCoordinates(coords);
      map.fitBounds(b as LngLatBoundsLike, { padding: 55, maxZoom: 14, duration: 0 });
    });

    return () => { map.remove(); mapRef.current = null; };
  }, [addressPoint, closestPoint, hexagon]);

  return <div ref={container} className="map" role="img" aria-label="Kaart met adres, afstandslijn en dichtstbijzijnd AERIUS-hexagoon" />;
}
