#!/usr/bin/env bash
set -euo pipefail

# Importeert de AERIUS 1-ha geometrieën + koppeltabel relevante habitats.
# Vereist: GDAL/ogr2ogr, psql, PostGIS.
#
# Gebruik:
#   OGR_PG='PG:host=localhost ...' DATABASE_URL='postgresql://...' \
#     ./scripts/import-aerius.sh /pad/hexagons.gpkg /pad/relevant-habitats.gpkg

HEX_GPKG=${1:?Geef de GeoPackage van het AERIUS hexagonengrid}
HAB_GPKG=${2:?Geef de GeoPackage van de koppeltabel relevante habitats}
: "${DATABASE_URL:?DATABASE_URL ontbreekt}"
: "${OGR_PG:?OGR_PG ontbreekt; gebruik een GDAL PostgreSQL connection string}"
RELEASE=${AERIUS_RELEASE:-AERIUS 2025}

layer_like() {
  local file=$1 pattern=$2
  ogrinfo -ro -so "$file" 2>/dev/null | sed -n 's/^ *[0-9][0-9]*: \([^ ]*\).*/\1/p' | grep -Ei "$pattern" | head -1
}

HEX_LAYER=${AERIUS_HEX_LAYER:-$(layer_like "$HEX_GPKG" '(^|:)hexagons$|hexagon')}
HAB_LAYER=${AERIUS_HAB_LAYER:-$(layer_like "$HAB_GPKG" 'hexagons_to_relevant_habitats|relevant.*habitat')}

if [[ -z "$HEX_LAYER" || -z "$HAB_LAYER" ]]; then
  echo "Kon laagnamen niet automatisch vinden." >&2
  echo "Stel AERIUS_HEX_LAYER en AERIUS_HAB_LAYER expliciet in." >&2
  exit 1
fi

echo "Hexagonen: $HEX_LAYER"
echo "Relevante habitats: $HAB_LAYER"

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/schema.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 <<'SQL'
DROP TABLE IF EXISTS stage_aerius_hexagons;
DROP TABLE IF EXISTS stage_aerius_habitats;
SQL

ogr2ogr -overwrite -f PostgreSQL "$OGR_PG" "$HEX_GPKG" "$HEX_LAYER" \
  -nln stage_aerius_hexagons -lco GEOMETRY_NAME=geom -t_srs EPSG:28992
ogr2ogr -overwrite -f PostgreSQL "$OGR_PG" "$HAB_GPKG" "$HAB_LAYER" \
  -nln stage_aerius_habitats -lco GEOMETRY_NAME=geom -t_srs EPSG:28992

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -v release="$RELEASE" <<'SQL'
BEGIN;
TRUNCATE aerius_relevant_hexagons, aerius_relevant_habitats;

INSERT INTO aerius_relevant_habitats
(receptor_id,zoom_level,natura2000_area_id,natura2000_area_name,habitat_type_id,habitat_type_name,habitat_type_description,critical_deposition,surface,coverage)
SELECT receptor_id::bigint, zoom_level::integer, natura2000_area_id::integer, natura2000_area_name::text,
       habitat_type_id::integer, habitat_type_name::text, habitat_type_description::text,
       critical_deposition::integer, surface::double precision, coverage::double precision
FROM stage_aerius_habitats
WHERE zoom_level::integer = 1;

INSERT INTO aerius_relevant_hexagons(receptor_id,zoom_level,natura2000_area_id,natura2000_area_name,geom)
SELECT DISTINCT h.receptor_id::bigint, 1, r.natura2000_area_id, r.natura2000_area_name,
       ST_Force2D(h.geom)::geometry(Polygon,28992)
FROM stage_aerius_hexagons h
JOIN (
  SELECT DISTINCT receptor_id::bigint, natura2000_area_id::integer, natura2000_area_name::text
  FROM stage_aerius_habitats
  WHERE zoom_level::integer=1
) r ON r.receptor_id=h.receptor_id::bigint
WHERE h.zoom_level::integer=1;

ANALYZE aerius_relevant_hexagons;
ANALYZE aerius_relevant_habitats;
INSERT INTO app_metadata(key,value,updated_at) VALUES ('aerius_release', :'release', now())
ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now();
COMMIT;
SQL

echo "Import gereed. Controleer aantallen:"
psql "$DATABASE_URL" -c "SELECT count(*) AS hexagons FROM aerius_relevant_hexagons; SELECT count(*) AS habitat_rows FROM aerius_relevant_habitats;"
