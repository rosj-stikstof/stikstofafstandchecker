#!/usr/bin/env bash
set -euo pipefail

# Download/import wrapper. Omdat RIVM bestandsnamen per release kunnen wijzigen,
# worden download-URL's bewust via environment variables gezet.
# Voorbeeld:
#   AERIUS_HEX_ZIP_URL='https://...' AERIUS_HAB_ZIP_URL='https://...' \
#   DATABASE_URL='...' OGR_PG='PG:...' ./scripts/update-aerius.sh

: "${AERIUS_HEX_ZIP_URL:?AERIUS_HEX_ZIP_URL ontbreekt}"
: "${AERIUS_HAB_ZIP_URL:?AERIUS_HAB_ZIP_URL ontbreekt}"
WORK=${WORKDIR:-$(mktemp -d)}
trap 'rm -rf "$WORK"' EXIT

curl -fL "$AERIUS_HEX_ZIP_URL" -o "$WORK/hex.zip"
curl -fL "$AERIUS_HAB_ZIP_URL" -o "$WORK/hab.zip"
unzip -q "$WORK/hex.zip" -d "$WORK/hex"
unzip -q "$WORK/hab.zip" -d "$WORK/hab"
HEX_GPKG=$(find "$WORK/hex" -iname '*.gpkg' | head -1)
HAB_GPKG=$(find "$WORK/hab" -iname '*.gpkg' | head -1)
[[ -n "$HEX_GPKG" && -n "$HAB_GPKG" ]] || { echo 'GeoPackage niet gevonden in download.' >&2; exit 1; }

"$(dirname "$0")/import-aerius.sh" "$HEX_GPKG" "$HAB_GPKG"
