CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS aerius_relevant_hexagons (
  receptor_id bigint NOT NULL,
  zoom_level integer NOT NULL,
  natura2000_area_id integer NOT NULL,
  natura2000_area_name text NOT NULL,
  geom geometry(Polygon, 28992) NOT NULL,
  PRIMARY KEY (receptor_id, natura2000_area_id, zoom_level)
);
CREATE INDEX IF NOT EXISTS aerius_relevant_hexagons_geom_gix ON aerius_relevant_hexagons USING gist (geom);

CREATE TABLE IF NOT EXISTS aerius_relevant_habitats (
  receptor_id bigint NOT NULL,
  zoom_level integer NOT NULL,
  natura2000_area_id integer NOT NULL,
  natura2000_area_name text NOT NULL,
  habitat_type_id integer,
  habitat_type_name text,
  habitat_type_description text,
  critical_deposition integer,
  surface double precision,
  coverage double precision
);
CREATE INDEX IF NOT EXISTS aerius_relevant_habitats_receptor_idx ON aerius_relevant_habitats (receptor_id, zoom_level, natura2000_area_id);

CREATE TABLE IF NOT EXISTS app_metadata (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO app_metadata(key,value) VALUES ('aerius_release','AERIUS 2025') ON CONFLICT (key) DO NOTHING;
