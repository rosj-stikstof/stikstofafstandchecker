import { NextRequest, NextResponse } from 'next/server';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function parseRD(wkt: unknown): [number, number] | null {
  if (typeof wkt !== 'string') return null;
  const match = /^POINT\s*\(\s*([\d.]+)\s+([\d.]+)\s*\)$/i.exec(wkt);
  if (!match) return null;
  return [Number(match[1]), Number(match[2])];
}

export async function POST(req: NextRequest) {
  try {
    const { address } = await req.json();
    if (typeof address !== 'string' || address.trim().length < 6 || address.length > 180) {
      return NextResponse.json({ error: 'Vul een volledig Nederlands adres in.' }, { status: 400 });
    }
    const u = new URL('https://api.pdok.nl/bzk/locatieserver/search/v3_1/free');
    u.searchParams.set('q', address.trim());
    u.searchParams.set('rows', '1');
    u.searchParams.set('fq', 'type:adres');
    const geo = await fetch(u, { signal: AbortSignal.timeout(8000), cache: 'no-store' });
    if (!geo.ok) return NextResponse.json({ error: 'PDOK is tijdelijk niet bereikbaar.' }, { status: 502 });
    const body = await geo.json();
    const doc = body.response?.docs?.[0];
    const point = parseRD(doc?.centroide_rd);
    if (!point) return NextResponse.json({ error: 'Geen volledig adres gevonden. Kies een adres uit de suggesties.' }, { status: 404 });
    const resolvedAddress = doc.weergavenaam ?? address.trim();
    const [x, y] = point;
    const sql = `
      WITH p AS (
        SELECT ST_SetSRID(ST_MakePoint($1,$2),28992) AS geom
      ), nearest AS (
        SELECT h.receptor_id, h.natura2000_area_id, h.natura2000_area_name, h.geom,
               ST_Distance(h.geom, p.geom) AS distance_m,
               ST_ClosestPoint(h.geom, p.geom) AS closest_rd,
               p.geom AS address_rd
        FROM aerius_relevant_hexagons h CROSS JOIN p
        WHERE h.zoom_level = 1
        ORDER BY h.geom <-> p.geom
        LIMIT 1
      )
      SELECT n.receptor_id, n.natura2000_area_id, n.natura2000_area_name, n.distance_m,
             ST_AsGeoJSON(ST_Transform(n.geom,4326))::json AS hexagon_geojson,
             ARRAY[ST_X(ST_Transform(n.address_rd,4326)), ST_Y(ST_Transform(n.address_rd,4326))] AS address_point,
             ARRAY[ST_X(ST_Transform(n.closest_rd,4326)), ST_Y(ST_Transform(n.closest_rd,4326))] AS closest_point,
             COALESCE(array_agg(DISTINCT rh.habitat_type_name) FILTER (WHERE rh.habitat_type_name IS NOT NULL), '{}') AS habitat_types,
             MIN(rh.critical_deposition) AS critical_deposition,
             (SELECT value FROM app_metadata WHERE key='aerius_release') AS dataset_release
      FROM nearest n
      LEFT JOIN aerius_relevant_habitats rh
        ON rh.receptor_id=n.receptor_id AND rh.zoom_level=1 AND rh.natura2000_area_id=n.natura2000_area_id
      GROUP BY n.receptor_id,n.natura2000_area_id,n.natura2000_area_name,n.distance_m,n.geom,n.address_rd,n.closest_rd;
    `;
    const { rows } = await pool.query(sql, [x, y]);
    if (!rows[0]) return NextResponse.json({ error: 'Geen relevante AERIUS-hexagoon gevonden. Is de dataset geïmporteerd?' }, { status: 404 });

    const row = rows[0];
    return NextResponse.json({
      address: address.trim(),
      resolved_address: resolvedAddress,
      receptor_id: Number(row.receptor_id),
      natura2000_area_id: Number(row.natura2000_area_id),
      natura2000_area_name: row.natura2000_area_name,
      distance_m: Number(row.distance_m),
      habitat_types: row.habitat_types ?? [],
      critical_deposition: row.critical_deposition == null ? null : Number(row.critical_deposition),
      address_point: row.address_point.map(Number),
      closest_point: row.closest_point.map(Number),
      hexagon_geojson: row.hexagon_geojson,
      dataset_release: row.dataset_release
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'De afstand kon niet worden berekend.' }, { status: 500 });
  }
}
