import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim() ?? '';
  if (q.length < 4 || q.length > 180) return NextResponse.json({ suggestions: [] });
  const url = new URL('https://api.pdok.nl/bzk/locatieserver/search/v3_1/suggest');
  url.searchParams.set('q', q);
  url.searchParams.set('rows', '7');
  url.searchParams.set('fq', 'type:adres');
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(8000), cache: 'no-store' });
    if (!r.ok) throw new Error('PDOK unavailable');
    const data = await r.json();
    return NextResponse.json({ suggestions: (data.response?.docs ?? []).map((d: { weergavenaam?: string; id?: string }) => ({ label: d.weergavenaam, id: d.id })).filter((d: { label?: string }) => d.label) });
  } catch {
    return NextResponse.json({ error: 'PDOK is tijdelijk niet bereikbaar.' }, { status: 502 });
  }
}
