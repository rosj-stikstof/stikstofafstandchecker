import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import 'maplibre-gl/dist/maplibre-gl.css';
import './styles.css';

export const metadata: Metadata = {
  title: 'Stikstofafstand | Natura 2000',
  description: 'Bereken de hemelsbrede afstand tot het dichtstbijzijnde relevante stikstofgevoelige AERIUS-hexagoon.'
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  );
}
