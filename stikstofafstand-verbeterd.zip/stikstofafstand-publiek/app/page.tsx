'use client';

import { FormEvent, KeyboardEvent, useEffect, useRef, useState } from 'react';
import type { Geometry } from 'geojson';
import ResultMap from '../components/ResultMap';

type Suggestion = { label: string; id?: string };
type Result = {
  address: string;
  resolved_address: string;
  distance_m: number;
  natura2000_area_id: number;
  natura2000_area_name: string;
  receptor_id: number;
  habitat_types: string[];
  critical_deposition: number | null;
  address_point: [number, number];
  closest_point: [number, number];
  hexagon_geojson: Geometry;
  dataset_release: string;
};

function distanceLabel(m: number) {
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} km`;
}

export default function Home() {
  const [address, setAddress] = useState('');
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [active, setActive] = useState(-1);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => { if (debounce.current) clearTimeout(debounce.current); }, []);

  function changeAddress(value: string) {
    setAddress(value); setResult(null); setActive(-1);
    if (debounce.current) clearTimeout(debounce.current);
    if (value.trim().length < 4) { setSuggestions([]); return; }
    debounce.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/suggest?q=${encodeURIComponent(value.trim())}`);
        const data = await r.json();
        if (r.ok) setSuggestions(data.suggestions ?? []);
      } catch { setSuggestions([]); }
    }, 220);
  }

  function choose(s: Suggestion) {
    setAddress(s.label); setSuggestions([]); setActive(-1);
  }

  function keyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (!suggestions.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(v => Math.min(v + 1, suggestions.length - 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setActive(v => Math.max(v - 1, 0)); }
    if (e.key === 'Escape') { setSuggestions([]); setActive(-1); }
    if (e.key === 'Enter' && active >= 0) { e.preventDefault(); choose(suggestions[active]); }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(''); setResult(null); setSuggestions([]);
    try {
      const r = await fetch('/api/check', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ address })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Onbekende fout');
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Onbekende fout');
    } finally { setBusy(false); }
  }

  return (
    <main>
      <header className="siteHeader"><div className="shell brand"><span className="mark">N2000</span><span>Stikstofafstand</span></div></header>
      <section className="hero">
        <div className="shell heroGrid">
          <div>
            <span className="eyebrow">AERIUS 1-ha hexagonen</span>
            <h1>Hoe ver ligt stikstofgevoelige Natura 2000-natuur?</h1>
            <p className="lead">Vul een Nederlands adres in. We meten hemelsbreed vanaf het geocodeerde adrespunt tot de rand van het dichtstbijzijnde relevante stikstofgevoelige AERIUS-hexagoon.</p>
            <form onSubmit={submit} className="searchCard">
              <label htmlFor="address">Adres</label>
              <div className="autocomplete">
                <div className="row">
                  <input id="address" autoComplete="off" value={address} onChange={e => changeAddress(e.target.value)} onKeyDown={keyDown} placeholder="Bijv. Kalmoesplantsoen 9, Den Haag" required />
                  <button disabled={busy}>{busy ? 'Berekenen…' : 'Bereken afstand'}</button>
                </div>
                {suggestions.length > 0 && <div className="suggestions" role="listbox">
                  {suggestions.map((s, i) => <button type="button" role="option" aria-selected={i === active} className={i === active ? 'suggestion active' : 'suggestion'} key={`${s.id ?? s.label}-${i}`} onMouseDown={() => choose(s)}>{s.label}</button>)}
                </div>}
              </div>
              <div className="privacy">Adresgegevens worden door deze starter niet permanent opgeslagen.</div>
            </form>
            {error && <div className="error">{error}</div>}
          </div>
          <aside className="infoPanel"><b>Wat meten we?</b><p>De kortste afstand tot de geometrie van een relevant AERIUS-hexagoon op zoomlevel 1 (1 hectare), niet tot het middelpunt van een Natura 2000-gebied.</p></aside>
        </div>
      </section>

      {result && <section className="shell resultSection">
        <div className="resultTop">
          <div className="resultCard">
            <span className="eyebrow">Dichtstbijzijnde stikstofgevoelige AERIUS-locatie</span>
            <div className="distance">{distanceLabel(result.distance_m)}</div>
            <h2>{result.natura2000_area_name}</h2>
            <p className="resolved">Vanaf {result.resolved_address}</p>
            <div className="metrics">
              <div><span>AERIUS receptor</span><b>{result.receptor_id}</b></div>
              <div><span>Natura 2000 ID</span><b>{result.natura2000_area_id}</b></div>
              <div><span>KDW</span><b>{result.critical_deposition ?? '—'}</b></div>
              <div><span>Dataset</span><b>{result.dataset_release}</b></div>
            </div>
            {result.habitat_types?.length > 0 && <div className="habitats"><span>Relevante habitats</span><div>{result.habitat_types.map(h => <code key={h}>{h}</code>)}</div></div>}
          </div>
          <div className="mapCard"><ResultMap addressPoint={result.address_point} closestPoint={result.closest_point} hexagon={result.hexagon_geojson} /></div>
        </div>
        <div className="disclaimer"><b>Let op:</b> deze afstand is informatief. Afstand alleen bepaalt niet of een project vergunningplichtig is of stikstofdepositie veroorzaakt. Daarvoor kan een projectspecifieke AERIUS-berekening en juridisch/ecologisch advies nodig zijn.</div>
      </section>}

      <section className="shell how"><h2>Zo werkt de checker</h2><div className="steps"><div><b>1</b><span>Adres via PDOK</span><p>Het adres wordt geocodeerd naar een exact locatiepunt.</p></div><div><b>2</b><span>AERIUS + PostGIS</span><p>Een spatial index zoekt het dichtstbijzijnde relevante 1-ha-hexagoon.</p></div><div><b>3</b><span>Afstand tot rand</span><p>PostGIS meet de kortste hemelsbrede afstand in Rijksdriehoekscoördinaten.</p></div></div></section>
      <footer><div className="shell">Databronnen: PDOK/Kadaster en AERIUS/RIVM. Controleer bij productie altijd de gebruikte AERIUS-release.</div></footer>
    </main>
  );
}
